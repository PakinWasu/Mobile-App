package com.example.hw7

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
