import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

main() {
  runApp(const ShowInf());
}

class ShowInf extends StatefulWidget {
  const ShowInf({super.key});

  @override
  State<ShowInf> createState() => _ShowInfState();
}

class _ShowInfState extends State<ShowInf> {
  List list = [];
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();

  Future<String> listData() async {
    var response = await http.get(
      Uri.http('10.110.0.200:8080', 'emp'),
      headers: {"Accept": "application/json"},
    );
    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');
    setState(() {
      list = jsonDecode(response.body);
    });
    return "Success";
  }

  @override
  void initState() {
    super.initState();
    listData();
  }

  String checkBMI(double weight, double height) {
    double bmi = weight / ((height / 100) * (height / 100));

    double minWeight = 18.5 * (height / 100) * (height / 100);

    double maxWeight = 24.9 * (height / 100) * (height / 100);

    if (bmi < 18.5) {
      double weightToGain = minWeight - weight;
      return 'You need to gain ${weightToGain.toStringAsFixed(2)} kg to reach a normal BMI.';
    } else if (bmi >= 18.5 && bmi <= 24.9) {
      return 'Good Health.';
    } else {
      double weightToLose = weight - maxWeight;
      return 'You need to lose ${weightToLose.toStringAsFixed(2)} kg to reach a normal BMI.';
    }
  }

  String pic(double bmi) {
    if (bmi < 18.5) {
      return 'assets/images/bmi-1.png';
    } else if (bmi < 24.9) {
      return 'assets/images/bmi-2.png';
    } else if (bmi < 29.9) {
      return 'assets/images/bmi-4.png';
    } else {
      return 'assets/images/bmi-5.png';
    }
  }

  String calculateBmi(double weight, double height) {
    double bmi = weight / ((height / 100) * (height / 100));
    return bmi.toStringAsFixed(2);
  }

  String determineBmiType(double bmi) {
    if (bmi < 18.5) {
      return 'Underweight';
    } else if (bmi < 24.9) {
      return 'Normal';
    } else if (bmi < 29.9) {
      return 'Overweight';
    } else {
      return 'Obese';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('DB Test')),
      body: Center(
        child: ListView.builder(
          itemCount: list.length,
          itemBuilder: (BuildContext context, int index) {
            return Card(
              child: ListTile(
                title: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Name: ${list[index]["name"]}'),
                    Text('Email: ${list[index]["email"]}'),
                    Text(
                      'BMI: ${calculateBmi(list[index]['weight'], list[index]['height'])}',
                    ),
                    Text(
                      'BMI TYPE: ${determineBmiType(double.parse(calculateBmi(list[index]['weight'], list[index]['height'])))}',
                    ),
                    Image.asset(
                      pic(
                        double.parse(
                          calculateBmi(
                            list[index]['weight'],
                            list[index]['height'],
                          ),
                        ),
                      ),
                    ),
                    Text(
                      checkBMI(list[index]['weight'], list[index]['height']),
                    ),
                  ],
                ),
                leading: Text(list[index]["id"].toString()),
                trailing: Wrap(
                  spacing: 5,
                  children: [
                    IconButton(
                      icon: Icon(Icons.edit, color: Colors.green),
                      onPressed: () {
                        Map data = {
                          'id': list[index]['id'],
                          'name': list[index]['name'],
                          'email': list[index]['email'],
                          'phone': list[index]['phone'],
                          'address': list[index]['address'],
                          'height': list[index]['height'],
                          'weight': list[index]['weight'],
                        };
                        _showedit(data);
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline, color: Colors.red),
                      onPressed: () => _showDel(list[index]["id"]),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () {
          _addNewDialog();
        },
      ),
    );
  }

  Future<void> _addNewDialog() async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Add New Employee'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                TextField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp name",
                    labelText: "Name",
                  ),
                ),
                TextField(
                  controller: _emailController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp Email",
                    labelText: "Email",
                  ),
                ),
                TextField(
                  controller: _phoneController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp phone",
                    labelText: "Phone",
                  ),
                ),
                TextField(
                  controller: _addressController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp Address",
                    labelText: "Address",
                  ),
                ),
                TextField(
                  controller: _heightController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp height",
                    labelText: "Height",
                  ),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: _weightController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp weight",
                    labelText: "Weight",
                  ),
                  keyboardType: TextInputType.number,
                ),
                const Text('กรอกข้อมูลให้เรียบร้อยแล้วกด ยืนยัน'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('ยืนยัน'),
              onPressed: () {
                add_data();
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _showDel(int id) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('ลบข้อมูล ${id}'),
          content: SingleChildScrollView(
            child: ListBody(
              children: const <Widget>[Text('ยืนยันการลบข้อมูล กด ยืนยัน')],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('ยืนยัน'),
              onPressed: () {
                del_data(id);
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void add_data() async {
    Map data = {
      'name': _nameController.text,
      'email': _emailController.text,
      'phone': _phoneController.text,
      'address': _addressController.text,
      'height': _heightController.text,
      'weight': _weightController.text,
    };
    var body = jsonEncode(data);
    var response = await http.post(
      Uri.http('10.110.0.200:8080', 'create'),
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
      body: body,
    );

    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');
    listData();
  }

  void del_data(int id) async {
    var response = await http.delete(
      Uri.http('10.110.0.200:8080', 'delete/$id'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
        "Accept": "application/json",
      },
    );
    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');
    listData();
  }

  Future<void> _showedit(Map data) async {
    _nameController.text = data['name'];
    _emailController.text = data['email'];
    _phoneController.text = data['phone'];
    _addressController.text = data['address'];
    _heightController.text = data['height'].toString();
    _weightController.text = data['weight'].toString();
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Edit Employee'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                TextField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp name",
                    labelText: "Name",
                  ),
                ),
                TextField(
                  controller: _emailController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp Email",
                    labelText: "Email",
                  ),
                ),
                TextField(
                  controller: _phoneController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp phone",
                    labelText: "Phone",
                  ),
                ),
                TextField(
                  controller: _addressController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp Address",
                    labelText: "Address",
                  ),
                ),
                TextField(
                  controller: _heightController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp height",
                    labelText: "Height",
                  ),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: _weightController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp weight",
                    labelText: "Weight",
                  ),
                  keyboardType: TextInputType.number,
                ),
                const Text('ปรับปรุงข้อมูลให้เรียบร้อยแล้วกด ยืนยัน'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('ยืนยัน'),
              onPressed: () {
                edit_data(data['id']);
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void edit_data(id) async {
    Map data = {
      'name': _nameController.text,
      'email': _emailController.text,
      'phone': _phoneController.text,
      'address': _addressController.text,
      'height': _heightController.text,
      'weight': _weightController.text,
    };
    var body = jsonEncode(data);
    var response = await http.put(
      Uri.http('10.110.0.200:8080', 'update/$id'),
      headers: <String, String>{
        "Content-Type": "application/json; charset=UTF-8",
      },
      body: body,
    );
    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');
    listData();
  }
}
