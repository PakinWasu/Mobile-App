class Model {
  final String id;
  final String name;
  final String address;
  final String email;
  final double height;
  final double weight;

  Model._({
    required this.id,
    required this.name,
    required this.address,
    required this.email,
    required this.height,
    required this.weight,
  });

  factory Model.fromJson(Map<String, dynamic> json) {
    return Model._(
      id: json['id'],
      name: json['name'],
      address: json['address'],
      email: json['email'],
      height: json['height'].toDouble(),
      weight: json['weight'].toDouble(),
    );
  }
}
